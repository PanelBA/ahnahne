import { Planing } from './planing';

describe('Planing', () => {
  it('should create an instance', () => {
    expect(new Planing()).toBeTruthy();
  });
});
