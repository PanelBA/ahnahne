import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormationRoutingModule } from './formation-routing.module';
import { ListerformationComponent } from './listerformation/listerformation.component';
import { CalendrierformationComponent } from './calendrierformation/calendrierformation.component';
import { FormationComponent } from './formation/formation.component';
import { FormsModule, ReactiveFormsModule }  from '@angular/forms';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { Routes, RouterModule } from '@angular/router';
import { OuvrirsessionComponent } from './ouvrirsession/ouvrirsession.component';
import { ListformationmoduleComponent } from './listformationmodule/listformationmodule.component';
import { ListformationmetiersComponent } from './listformationmetiers/listformationmetiers.component';
import { PromotionComponent } from './promotion/promotion.component';
import { ChoisirpromotionComponent } from './choisirpromotion/choisirpromotion.component';
import { IDropdownSettings } from 'ng-multiselect-dropdown';
import { NgMultiSelectDropDownModule } from 'ng-multiselect-dropdown';
import { ListerprogrammekhdemniComponent } from './listerprogrammekhdemni/listerprogrammekhdemni.component';
import {MatButtonModule } from '@angular/material/button';
import {MatIconModule} from '@angular/material';
import {MatTableModule} from '@angular/material/table';
import { MatPaginatorModule , MatInputModule , MatFormFieldModule,MatRadioModule,MatNativeDateModule, NativeDateModule, MatDatepickerModule} from '@angular/material';
 import {MatSnackBarModule} from '@angular/material/snack-bar';
import {MatCardModule} from '@angular/material/card';
import {MatTooltipModule} from '@angular/material/tooltip';
import {MatSelectModule} from '@angular/material/select';
import {MatExpansionModule} from '@angular/material/expansion';

@NgModule({
  declarations: [ ListerformationComponent, CalendrierformationComponent, FormationComponent,  OuvrirsessionComponent, ListformationmoduleComponent, ListformationmetiersComponent, PromotionComponent, ChoisirpromotionComponent,  ListerprogrammekhdemniComponent],
  imports: [
    CommonModule,
    FormationRoutingModule ,MatButtonModule,MatIconModule,MatTableModule,MatPaginatorModule , MatInputModule ,
    MatFormFieldModule,MatRadioModule,MatNativeDateModule, NativeDateModule, MatDatepickerModule,
    NgbModule ,MatSnackBarModule,MatCardModule,MatTooltipModule,MatSelectModule,MatExpansionModule,
    FormsModule,
    ReactiveFormsModule
 ,RouterModule ,NgMultiSelectDropDownModule.forRoot()
  ]
})
export class FormationModule { }
