import { Component, OnInit } from '@angular/core';
import {FormControl,FormGroup,Validators} from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';
import {Promotion} from '../../../Model/promotion';
import { FormsModule} from '@angular/forms';
import {PromotionService} from '../../../Service/promotion.service';
import { NgbModalConfig, NgbModal } from '@ng-bootstrap/ng-bootstrap';
import {NgControl,ValidationErrors } from '@angular/forms';
import { HttpClient, HttpEventType } from '@angular/common/http';
import { IDropdownSettings } from 'ng-multiselect-dropdown';
import {Session} from '../../../Model/session';
import {SessionService} from '../../../Service/session.service';
import {Remise} from '../../../Model/remise';
import {RemiseService} from '../../../Service/remise.service';
@Component({
  selector: 'app-promotion',
  templateUrl: './promotion.component.html',
  styleUrls: ['./promotion.component.scss']
})
export class PromotionComponent implements OnInit {

constructor(private remiseservice:RemiseService ,private sessionservice :SessionService ,private promotionservice :PromotionService,private httpClient: HttpClient ,private _Activatedroute:ActivatedRoute,config: NgbModalConfig, private modalService: NgbModal , private router: Router ,private promotionService: PromotionService) { }
 promotion : Promotion  = new Promotion();
 temp =new Array();
promotions : Promotion[] = new Array();
  ngOnInit() {
   this.getAllPromotion() ;
   let tmp = [];

        this.sessionservice.getAllplanifier().subscribe((data: any) => {
          for(let i=0; i < data.length; i++) {
        tmp.push({ item_id: data[i].idsession , item_text: data[i].datedebut+""+data[i].datefin  });
      }
      this.dropdownList = tmp;
       });
   this.sessionselectionne=[] ;

    this.selectedItems = [

    ];

 this.dropdownSettings = {
      singleSelection: false,
      idField: 'item_id',
      textField: 'item_text',
      selectAllText: 'Select All',
      unSelectAllText: 'UnSelect All',
      itemsShowLimit: 3,
      allowSearchFilter: true
    };

  }



/****************ajouter *******************/
open(contentAjout) {
    this.modalService.open(contentAjout);
  }
 messageajout : String ;
ajouter(promotion :Promotion){
this.promotionservice.save(promotion).subscribe(data => {

if (data.success) {
    this.getAllPromotion();
  this.messageajout ="promotion   ajoutée ";
  } else {
          this.messageajout ="echec  d'ajout ";
}
 console.log(data) }, error => console.log(error));
}



/**********************************************/
private getAllPromotion() {
 this.promotionService.getAll().subscribe(data => {
 this.promotions=data ;
      console.log(this.promotions);
    }, ex => {
      console.log(ex);
    });}

    /*****************  supprmer *************/
    message :String ;

 delete(id: number) {

    this.promotionService.delete(id).subscribe(data => {

if (data.success) {
    this.getAllPromotion();
  this.message ="promotion supprimé ";
  } else {
          this.message ="echec  du suppression ";
}
   }, ex => {

     console.log(ex);
    });
  }

/*******************modif **************************/
  messagemodif :String ;
   promotionmodif : Promotion  = new Promotion();

  openmodif(contentModif , id :number) {

    this.modalService.open(contentModif);
  this.promotionService.getpromotion(id)
      .subscribe(data => {
        console.log(data)
        this.promotionmodif = data;
      }, error => console.log(error));
  }

  private update(promotionmodif:Promotion) {
    this.promotionService.update(promotionmodif).subscribe(
   data => {
if (data.success) {
    this.getAllPromotion();
  this.messagemodif ="Promotion modifié ";
  } else {
          this.messagemodif ="Echec  du modification ";
}
    }, ex => {console.log(ex);
    });
  }

/************** affect formation ***********/
   session :Session ;
 id :number ;
   sessions : Session[] = new Array();
   sessionselectionne  : Session[] =new Array();
   promo :Promotion =new Promotion();
   remise :Remise =new Remise();
   affect : boolean ;
sessionselct :Session ;
messageaffect :String ;
openpromotion(contentpromotion, id :number){
    this.modalService.open(contentpromotion);
              this.promotionService.getpromotion(id)
      .subscribe(data => {
        console.log(data)
        this.promo = data;

      }, error => console.log(error));



     }



affecter(remise :Remise)
{

for(let i=0;i<this.selectedItems.length ;i++)
{  this.sessionservice.get(this.selectedItems[i].item_id).subscribe(data => {
        console.log(data) ;



this.remiseservice.add(remise,this.promo.idpromotion,data.idsession).subscribe(data => {
if (data!=null) {

 this.sessionselectionne=[] ;
  this.selectedItems = [ ];
  }
    }, ex => {
      console.log(ex);
    });



   }, error => console.log(error));
}
}
/******************/


  dropdownList = [];
  selectedItems = [];
  dropdownSettings :IDropdownSettings  = {};

  onItemSelect(item: any) {



}
  onSelectAll(items: any) {

  }

 onItemDeSelect(item:any)
{

}
 onDeSelectAll(items:any)
{
}

listesessions : Session[] =new Array() ;

openlistesession(contentsession, id :number){
    this.modalService.open(contentsession);
              this.remiseservice.getsession(id)
      .subscribe(data => {
        console.log(data)   ;
        this.listesessions = data;

      }, error => console.log(error));
}



}
