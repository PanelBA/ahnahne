import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { RouterModule , Routes } from '@angular/router';
import { FormsModule ,ReactiveFormsModule } from '@angular/forms';
import { AppRoutingModule } from './app-routing.module';
import {httpInterceptorProviders} from './Service/auth-interceptor';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { AppComponent } from './app.component';
import { NavbarComponent } from './navbar/navbar.component';
import { SidebarComponent } from './sidebar/sidebar.component';
import { FooterComponent } from './footer/footer.component';
import { FormateurModule} from './Components/formateur/formateur.module';
import { FormationModule } from './Components/formation/formation.Module';
import {SalleModule} from './Components/salle/salle.module';
import { SessionModule} from './Components/session/session.Module';
import { LoginregistreModule } from './Components/loginregistre/loginregistre.Module';
import { HttpClientModule } from '@angular/common/http';
import { Router, ActivatedRoute, ParamMap } from '@angular/router';
import { AccplateformeComponent } from './accplateforme/accplateforme.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { MatSliderModule } from '@angular/material/slider';
import {MatButtonModule} from '@angular/material/button';
import {MatInputModule} from '@angular/material';


@NgModule({
  declarations: [
    AppComponent,
    NavbarComponent,
     SidebarComponent,
    FooterComponent,
    AccplateformeComponent,

  ],
  imports: [

    AppRoutingModule,MatInputModule,
    BrowserModule,
    RouterModule,
    AppRoutingModule,
    FormsModule,
    NgbModule,
    FormateurModule,
    LoginregistreModule ,

    FormationModule,
    SessionModule,
    SalleModule,ReactiveFormsModule ,HttpClientModule,MatButtonModule ,

  MatSliderModule ,


   BrowserAnimationsModule,
  ],
  providers: [httpInterceptorProviders ],
  bootstrap: [AppComponent]
})
export class AppModule { }
